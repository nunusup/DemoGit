package Test;

import java.util.ArrayList;

public class mainTest1 {
    public static void main(String[] args) {
        QL ql = new QL();
        ql.nhaphoten();
        ql.hiends();
        ql.Xoapt();
        ql.sapXeptheoTen();
    }
}
